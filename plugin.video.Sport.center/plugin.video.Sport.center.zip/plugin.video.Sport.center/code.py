import base64
from Crypto.Cipher import AES

	def decompile():
		
		secret_key = 'vertigo'
